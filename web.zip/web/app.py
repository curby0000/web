from flask import Flask, render_template, request, jsonify
from datetime import datetime, timedelta
import random

app = Flask(__name__)

# Meal cost database (approximate prices in PHP)
MEAL_DATABASE = {
    'breakfast': [
        {'name': 'Pandesal with Egg & Coffee', 'cost': 35, 'healthy': 7, 'calories': 250},
        {'name': 'Oatmeal with Banana & Milk', 'cost': 40, 'healthy': 9, 'calories': 280},
        {'name': 'Corned Beef Silog', 'cost': 55, 'healthy': 5, 'calories': 450},
        {'name': 'Tocino Silog', 'cost': 60, 'healthy': 4, 'calories': 480},
        {'name': 'Fruit Salad & Yogurt', 'cost': 45, 'healthy': 9, 'calories': 200},
        {'name': 'Fried Rice & Hotdog', 'cost': 30, 'healthy': 3, 'calories': 350},
        {'name': 'Champorado with Milk', 'cost': 35, 'healthy': 5, 'calories': 300},
        {'name': 'Vegetable Omelette & Toast', 'cost': 50, 'healthy': 8, 'calories': 320},
    ],
    'lunch': [
        {'name': 'Adobo with Rice', 'cost': 65, 'healthy': 6, 'calories': 550},
        {'name': 'Sinigang na Baboy', 'cost': 70, 'healthy': 7, 'calories': 520},
        {'name': 'Chicken Curry', 'cost': 75, 'healthy': 6, 'calories': 580},
        {'name': 'Vegetable Stir-fry', 'cost': 50, 'healthy': 10, 'calories': 350},
        {'name': 'Pork Sisig', 'cost': 80, 'healthy': 4, 'calories': 620},
        {'name': 'Fish Fillet with Rice', 'cost': 60, 'healthy': 8, 'calories': 450},
        {'name': 'Tofu Steak', 'cost': 45, 'healthy': 9, 'calories': 380},
        {'name': 'Chicken Pastel', 'cost': 70, 'healthy': 6, 'calories': 500},
    ],
    'dinner': [
        {'name': 'Pancit Canton', 'cost': 45, 'healthy': 5, 'calories': 400},
        {'name': 'Giniling with Egg', 'cost': 55, 'healthy': 6, 'calories': 480},
        {'name': 'Fried Chicken & Rice', 'cost': 70, 'healthy': 4, 'calories': 600},
        {'name': 'Vegetable Soup & Rice', 'cost': 40, 'healthy': 9, 'calories': 320},
        {'name': 'Beef Tapa', 'cost': 75, 'healthy': 5, 'calories': 550},
        {'name': 'Lumpiang Shanghai', 'cost': 50, 'healthy': 5, 'calories': 420},
        {'name': 'Grilled Liempo', 'cost': 80, 'healthy': 3, 'calories': 650},
        {'name': 'Pinakbet', 'cost': 55, 'healthy': 8, 'calories': 380},
    ]
}

def generate_meal_plan(budget, days):
    """Generate optimized meal plan within budget"""
    daily_budget = budget / days
    meals = []
    total_cost = 0
    
    for day in range(1, days + 1):
        day_meals = {'day': day, 'meals': []}
        remaining_budget = daily_budget
        
        for meal_type in ['breakfast', 'lunch', 'dinner']:
            # Find affordable and healthy options
            options = MEAL_DATABASE[meal_type]
            affordable = [m for m in options if m['cost'] <= remaining_budget / 2]
            
            if affordable:
                # Prioritize healthier options (healthy score >= 7)
                healthy_options = [m for m in affordable if m['healthy'] >= 7]
                if healthy_options:
                    chosen = random.choice(healthy_options)
                else:
                    chosen = min(affordable, key=lambda x: x['cost'])  # cheapest
            else:
                # Pick cheapest if nothing affordable
                chosen = min(options, key=lambda x: x['cost'])
            
            day_meals['meals'].append({
                'type': meal_type.capitalize(),
                'name': chosen['name'],
                'cost': chosen['cost'],
                'healthy': chosen['healthy'],
                'calories': chosen['calories']
            })
            remaining_budget -= chosen['cost']
            total_cost += chosen['cost']
        
        # Add summary for the day
        total_health = sum(m['healthy'] for m in day_meals['meals'])
        total_calories = sum(m['calories'] for m in day_meals['meals'])
        day_meals['summary'] = {
            'total_cost': daily_budget - remaining_budget,
            'remaining': remaining_budget,
            'health_score': total_health,
            'calories': total_calories
        }
        meals.append(day_meals)
    
    # Statistics
    stats = {
        'total_cost': total_cost,
        'budget_left': budget - total_cost,
        'avg_daily_cost': total_cost / days,
        'avg_health_score': sum(m['summary']['health_score'] for m in meals) / days,
        'avg_calories': sum(m['summary']['calories'] for m in meals) / days
    }
    
    return meals, stats

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/generate', methods=['POST'])
def generate():
    data = request.json
    budget = float(data.get('budget', 0))
    days = int(data.get('days', 1))
    
    if budget <= 0 or days <= 0:
        return jsonify({'error': 'Invalid budget or days'}), 400
    
    meals, stats = generate_meal_plan(budget, days)
    return jsonify({'meals': meals, 'stats': stats})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)